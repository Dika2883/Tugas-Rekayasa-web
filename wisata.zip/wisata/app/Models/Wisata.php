<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Wisata extends Model
{
    // Nama tabel di database
    protected $table = 'wisata';

    // Primary key dari tabel
    protected $primaryKey = 'id_wisata';

    // Nonaktifkan timestamps (karena tabel tidak punya created_at dan updated_at)
    public $timestamps = false;

    /**
     * Kolom-kolom yang bisa diisi secara mass assignment
     */
    protected $fillable = [
        'kota',
        'landmark',
        'tarif',
    ];

    /**
     * Kolom-kolom yang disembunyikan saat model diubah jadi JSON
     */
    protected $hidden = [];
}
